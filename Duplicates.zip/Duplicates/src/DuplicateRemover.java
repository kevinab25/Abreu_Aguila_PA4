import java.io.*;
import java.util.ArrayList;

public class DuplicateRemover {
    ArrayList<String> uniqueWords = new ArrayList<String>();

    public void remove(String fileName) throws IOException {
        BufferedReader br1 = new BufferedReader(new FileReader(fileName));
        String line1 = br1.readLine();
        while(line1 != null)
        {
            String temp[] = line1.split(" ");
            for(String i:temp)
            {
                if(!uniqueWords.contains(i))   uniqueWords.add(i);
            }
            line1 = br1.readLine();
        }

        br1.close();
    }
    public void write(String fileName) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter(fileName);
        for(String i:uniqueWords)
        {
            pw.println(i);
        }
        pw.close();
    }
    }

