import java.io.FileNotFoundException;
import java.io.IOError;
import java.io.IOException;

public class Application {

    public static void main (String args[]) throws IOException {

        //Problem 1
        DuplicateRemover dupRemover = new DuplicateRemover();
        dupRemover.remove("problem1.txt");
        dupRemover.write("unique_words.txt");
        System.out.println("Duplicate Remover Operation successfully done");

        //Problem 2
        DuplicateCounter dupCounter = new DuplicateCounter();
        dupCounter.count("problem2.txt");
        dupCounter.write("unique_word_counts.txt");
        System.out.println("Duplicate Counter Operation successfully done");


    }


}
